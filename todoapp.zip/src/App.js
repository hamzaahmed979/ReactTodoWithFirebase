import logo from "./logo.svg";
import "./App.css";
import Todoapp from "./Component/Todoapp";
import { Component } from "react";
import AppRouter from "./Component/Config/Router";

class App extends Component {
  render() {
    return (
      <div>
        <AppRouter />
      </div>
    );
  }
}

export default App;
