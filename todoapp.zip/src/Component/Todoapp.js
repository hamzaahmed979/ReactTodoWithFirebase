import React from "react";
import firebase from "./Config/firebase.js";
import "firebase/database";
import {
  getDatabase,
  ref,
  set,
  push,
  get,
  remove,
  update,
} from "firebase/database";

class Todoapp extends React.Component {
  constructor() {
    super();
    this.state = {
      todo: [
        { title: "hamza", edit: false },
        { title: "ahmed", edit: false },
      ],
      value: "",
    };
  }

  AddItem = () => {
    const db = getDatabase();

    const obj = { title: this.state.value };

    const newItemRef = push(ref(db, "users/"));

    set(newItemRef, obj)
      .then(() => {
        console.log("Data added successfully!");
      })
      .catch((error) => {
        console.error("Error adding data:", error);
      });

    this.setState((prevState) => ({
      todo: [...prevState.todo, obj],
      value: "",
    }));
  };

  delete_todo = (index) => {
    const db = getDatabase();
    const usersRef = ref(db, "users/");

    get(usersRef)
      .then((snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.val();
          const keys = Object.keys(data);
          const keyToDelete = keys[index];

          const itemRef = ref(db, `users/${keyToDelete}`);

          remove(itemRef)
            .then(() => {
              console.log("Item deleted successfully from database!");

              this.setState((prevState) => {
                const updatedTodo = [...prevState.todo];
                updatedTodo.splice(index, 1);
                return { todo: updatedTodo };
              });
            })
            .catch((error) => {
              console.error("Error deleting item from database:", error);
            });
        } else {
          console.log("No data available to delete");
        }
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  };

  Delete_All = () => {
    const db = getDatabase();
    const usersRef = ref(db, "users/");

    // Remove all items from the database
    remove(usersRef)
      .then(() => {
        console.log("All items deleted successfully from database!");
        this.setState({ todo: [] });
      })
      .catch((error) => {
        console.error("Error deleting all items from database:", error);
      });
  };

  edit_todo = (index) => {
    this.setState((prevState) => {
      const updatedTodo = [...prevState.todo];
      updatedTodo[index].edit = true; // Enable edit mode for this item
      return { todo: updatedTodo };
    });
  };

  Update_todo = (index) => {
    const db = getDatabase();
    const usersRef = ref(db, "users/");

    get(usersRef)
      .then((snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.val();
          const keys = Object.keys(data);

          if (index >= 0 && index < keys.length) {
            const keyToUpdate = keys[index];
            const newValue = this.state.todo[index].title;

            const itemRef = ref(db, `users/${keyToUpdate}`);
            update(itemRef, { title: newValue })
              .then(() => {
                console.log("Item updated successfully in the database!");

                this.setState((prevState) => {
                  const updatedTodo = [...prevState.todo];
                  updatedTodo[index].edit = false; // Disable edit mode
                  return { todo: updatedTodo };
                });
              })
              .catch((error) => {
                console.error(
                  "Error updating item in the database:",
                  error.message
                );
              });
          }
        } else {
          console.log("No data available to update");
        }
      })
      .catch((error) => {
        console.error("Error fetching data:", error.message);
      });
  };

  handleChange = (e, index) => {
    const newTodo = [...this.state.todo];
    newTodo[index].title = e.target.value;
    this.setState({
      todo: newTodo,
    });
  };

  render() {
    let { todo, value } = this.state;
    return (
      <div>
        <input
          value={value}
          type="text"
          onChange={(e) => this.setState({ value: e.target.value })}
        />
        <button onClick={this.Delete_All}>Delete All</button>
        <button onClick={this.AddItem}>Add item</button>
        <ul>
          {todo.map((v, i) => (
            <li key={i}>
              {v.edit ? (
                <input
                  value={v.title}
                  type="text"
                  onChange={(e) => this.handleChange(e, i)}
                />
              ) : (
                v.title
              )}
              {v.edit ? (
                <button onClick={() => this.Update_todo(i)}>Update</button>
              ) : (
                <button onClick={() => this.edit_todo(i)}>Edit</button>
              )}
              <button onClick={() => this.delete_todo(i)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

export default Todoapp;
