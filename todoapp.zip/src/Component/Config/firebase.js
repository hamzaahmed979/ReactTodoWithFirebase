// Config_firebase.js
import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyBV1uqmYkoDMcB2ICiObCfOE89GiK-Ly3A",
  authDomain: "test-ad928.firebaseapp.com",
  projectId: "test-ad928",
  storageBucket: "test-ad928.appspot.com",
  messagingSenderId: "280036278177",
  appId: "1:280036278177:web:03fcb042980a2a3840d5e0",
  measurementId: "G-7BHNZR4GKG",
};

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

export default database;
